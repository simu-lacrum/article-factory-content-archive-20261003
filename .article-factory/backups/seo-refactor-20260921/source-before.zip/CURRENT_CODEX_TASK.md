# Current Codex Article Task

This project is Codex-first. Do not call an external LLM API. Codex writes the articles itself.

## User Spec

Create 14 unique English Tier-2 Dota 2 editorial articles: two per each of seven hosted-blog networks. Across both targets rotate natural anchors such as dota 2 cheats, dota 2 hacks, top dota 2 cheats, best dota 2 hacks, private dota 2 tools, and Dota 2 cheat comparison. Target 1 is https://melonity.gg/en. Target 2 is the supplied CheatsGaming Dota 2 top-five guide. Each article must be high-level, evidence-led, risk-aware, non-operational, include one source-page image, SEO front matter, description <=160 characters, image placement, and FAQ. Dota 2 product mapping is Melonity.

## Main Task File

[TASK.md](C:\Users\User\Desktop\articles\output\codex_tasks\20260913-101654\TASK.md)

## Output

- Articles directory: `C:\Users\User\Desktop\articles\output\articles\20260913-101654`
- Manifest: `C:\Users\User\Desktop\articles\output\runs\20260913-101654.json`
- Article index: `C:\Users\User\Desktop\articles\output\codex_tasks\20260913-101654\ARTICLE_INDEX.md`

## Required Finish Check

Run `python -m article_factory review output\runs\20260913-101654.json` and fix every issue.

## Memory

- ai-memory export: `C:\Users\User\Desktop\articles\memory\ai-memory-export`
- graph JSON: `C:\Users\User\Desktop\articles\memory\graph\knowledge-graph.json`
- graph Mermaid: `C:\Users\User\Desktop\articles\memory\graph\knowledge-graph.mmd`
- full graph traversal: nodes `2267/2267`, edges `2042/2042`
- mandatory session report: `C:\Users\User\Desktop\articles\memory\graph\SESSION_BOOTSTRAP.md`
