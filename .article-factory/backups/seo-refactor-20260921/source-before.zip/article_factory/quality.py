from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path

from .io_utils import read_text, write_text
from .products import product_for_game


RISK_PATTERNS = [
    (r"\b100%\s+(?:undetected|safe|безопасн|не\s*бан)", "Unsupported absolute safety guarantee"),
    (r"\b(?:bypass|evade|обход|обойти)\b.{0,40}\b(?:anti-?cheat|vac|античит)", "Operational anti-cheat evasion wording"),
    (r"\b(?:inject|инжект|driver|kernel|драйвер|ring\s*0)\b", "Low-level implementation detail"),
    (r"\b(?:exploit|уязвимост|эксплойт)\b", "Exploit framing"),
]

PLACEHOLDER_PATTERNS = [
    r"\bTODO\b",
    r"\bTBD\b",
    r"\[insert\b",
    r"\{\{[^}]+\}\}",
    r"<[^>]+>",
]

IMAGE_SLOT_PATTERN = re.compile(r"<!--\s*IMAGE_SLOT_(\d+)(.*?)-->", flags=re.I | re.S)


@dataclass
class ReviewFinding:
    severity: str
    message: str
    excerpt: str | None = None


def word_count(text: str) -> int:
    return len(re.findall(r"[\wа-яёА-ЯЁ'-]+", text))


def has_markdown_table(text: str) -> bool:
    separator = re.compile(r"\|?\s*:?-{3,}:?\s*(?:\|\s*:?-{3,}:?\s*)+\|?")
    lines = text.splitlines()
    for index, line in enumerate(lines):
        stripped = line.strip()
        if "|" not in stripped:
            continue
        if separator.fullmatch(stripped):
            previous_line = lines[index - 1].strip() if index else ""
            next_line = lines[index + 1].strip() if index + 1 < len(lines) else ""
            if "|" in previous_line or "|" in next_line:
                return True
        if stripped.startswith("|") and stripped.endswith("|") and index + 1 < len(lines):
            if separator.fullmatch(lines[index + 1].strip()):
                return True
    return False


def strip_front_matter(text: str) -> tuple[dict[str, str], str]:
    if not text.startswith("---"):
        return {}, text
    end = text.find("\n---", 3)
    if end == -1:
        return {}, text
    raw = text[3:end].strip()
    body = text[end + 4 :].strip()
    meta: dict[str, str] = {}
    for line in raw.splitlines():
        if ":" in line:
            key, value = line.split(":", 1)
            meta[key.strip()] = value.strip().strip('"')
    return meta, body


def generated_image_slots(text: str) -> list[dict[str, str | int | None]]:
    slots: list[dict[str, str | int | None]] = []
    for match in IMAGE_SLOT_PATTERN.finditer(text):
        body = match.group(2)
        if not re.search(r"^\s*Type:\s*generated image\s*$", body, flags=re.I | re.M):
            continue
        index_match = re.search(r"^\s*Generated sequence index:\s*(\d+)\s*$", body, flags=re.I | re.M)
        branch_match = re.search(r"^\s*Style branch:\s*(A|B1|B2|B3)\s*$", body, flags=re.I | re.M)
        qa_match = re.search(r"^\s*Prompt QA score:\s*(\d{1,3})\s*$", body, flags=re.I | re.M)
        slots.append(
            {
                "slot_id": int(match.group(1)),
                "sequence_index": int(index_match.group(1)) if index_match else None,
                "style_branch": branch_match.group(1).upper() if branch_match else None,
                "qa_score": int(qa_match.group(1)) if qa_match else None,
                "body": body,
            }
        )
    return slots


def review_article(article_path: Path, evidence_path: Path | None = None) -> dict:
    if not article_path.exists():
        return {
            "article": str(article_path),
            "status": "fail",
            "word_count": 0,
            "h2_count": 0,
            "evidence_sources": 0,
            "findings": [{"severity": "error", "message": "Article file does not exist"}],
        }
    text = read_text(article_path)
    meta, body = strip_front_matter(text)
    findings: list[ReviewFinding] = []
    if not meta:
        findings.append(ReviewFinding("error", "Missing front matter"))
    for key in ("title", "description", "game", "language", "primary_keyword"):
        if key not in meta:
            findings.append(ReviewFinding("warning", f"Missing front matter key: {key}"))
    title = meta.get("title", "").strip()
    seo_title = meta.get("seo_title", "").strip() or title
    description = meta.get("description", "").strip()
    primary_keyword = meta.get("primary_keyword", "").strip()
    if seo_title and len(seo_title) > 60:
        findings.append(ReviewFinding("warning", f"SEO title is longer than 60 characters: {len(seo_title)}"))
    if description and len(description) > 160:
        findings.append(ReviewFinding("warning", f"SEO description is longer than 160 characters: {len(description)}"))
    if primary_keyword and description and primary_keyword.lower() not in description.lower():
        findings.append(ReviewFinding("warning", "SEO description does not contain primary_keyword"))
    wc = word_count(body)
    if wc < 600:
        findings.append(ReviewFinding("warning", f"Article is short: {wc} words"))
    h2_count = len(re.findall(r"^##\s+", body, flags=re.M))
    if h2_count < 3:
        findings.append(ReviewFinding("warning", f"Only {h2_count} H2 sections found"))
    if has_markdown_table(body):
        findings.append(ReviewFinding("error", "Markdown tables are not allowed; use lists instead"))
    if not re.search(r"\bFAQ\b|частые вопросы|часто задаваемые вопросы|вопросы и ответы", body, flags=re.I):
        findings.append(ReviewFinding("warning", "No FAQ section detected"))
    visuals_opt_out = meta.get("visuals", "").strip().lower() in {"none", "no", "false", "omitted"}
    if not visuals_opt_out and not re.search(r"!\[[^\]]*\]\(|(?:image|screenshot)[_\s]+slot|image\s+placement|photo\s+placement|фото|изображени", body, flags=re.I):
        findings.append(ReviewFinding("warning", "No image placement notes detected"))
    product = meta.get("product", "").strip() or product_for_game(meta.get("game"))
    generated_slots = generated_image_slots(body)
    expected_accent = None
    if product == "Melonity":
        expected_accent = "#FF1469"
    elif product == "cluster.center":
        expected_accent = "#635FD5"
    for slot in generated_slots:
        slot_id = slot["slot_id"]
        sequence_index = slot["sequence_index"]
        style_branch = slot["style_branch"]
        qa_score = slot["qa_score"]
        slot_body = str(slot["body"])
        if sequence_index is None:
            findings.append(ReviewFinding("error", f"IMAGE_SLOT_{slot_id:02d} is missing a numeric Generated sequence index"))
        if style_branch is None:
            findings.append(ReviewFinding("error", f"IMAGE_SLOT_{slot_id:02d} is missing Style branch A/B1/B2/B3"))
        if sequence_index is not None and style_branch is not None:
            expected_branch = "B" if sequence_index % 2 else "A"
            if not style_branch.startswith(expected_branch):
                findings.append(
                    ReviewFinding(
                        "error",
                        f"IMAGE_SLOT_{slot_id:02d} breaks visual alternation: index {sequence_index} requires branch {expected_branch}",
                    )
                )
        if style_branch is not None and style_branch.startswith("B"):
            reference_files = set(
                re.findall(
                    r"article-editorial-warm-story-v1[/\\]reference-\d{2}\.png",
                    slot_body,
                    flags=re.I,
                )
            )
            if len(reference_files) < 2:
                findings.append(
                    ReviewFinding(
                        "error",
                        f"IMAGE_SLOT_{slot_id:02d} branch B must name two actual warm-story reference files",
                    )
                )
            if re.search(r"Reference roles:\s*none", slot_body, flags=re.I):
                findings.append(ReviewFinding("error", f"IMAGE_SLOT_{slot_id:02d} branch B cannot use Reference roles: none"))
            if not re.search(r"(?:Reference fidelity[^\n]*4/5|4/5[^\n]*fidelity)", slot_body, flags=re.I):
                findings.append(
                    ReviewFinding(
                        "error",
                        f"IMAGE_SLOT_{slot_id:02d} branch B is missing the 4/5 reference-fidelity target",
                    )
                )
            if expected_accent and not re.search(
                r"(?:dominant(?:\s+brand)?\s+field|field[^\n.]*replac(?:e|es|ing)[^\n.]*yellow|replac(?:e|es|ing)[^\n.]*yellow[^\n.]*field|доминирующ\w*\s+пол\w*|замен\w*[^\n.]*желт\w*[^\n.]*фон)",
                slot_body,
                flags=re.I,
            ):
                findings.append(
                    ReviewFinding(
                        "error",
                        f"IMAGE_SLOT_{slot_id:02d} branch B must use mapped brand color {expected_accent} as the dominant field replacing yellow/amber",
                    )
                )
        if expected_accent and expected_accent.lower() not in slot_body.lower():
            findings.append(
                ReviewFinding(
                    "error",
                    f"IMAGE_SLOT_{slot_id:02d} is missing mapped brand color {expected_accent} for {product}",
                )
            )
        if "gemini-3-pro-image" not in slot_body or "Nano Banana Pro" not in slot_body:
            findings.append(ReviewFinding("error", f"IMAGE_SLOT_{slot_id:02d} does not name Nano Banana Pro / gemini-3-pro-image"))
        if qa_score is None or qa_score < 80:
            findings.append(ReviewFinding("error", f"IMAGE_SLOT_{slot_id:02d} has no passing Prompt QA score (minimum 80)"))
    if product != "the mapped product" and not re.search(re.escape(product), body, flags=re.I):
        findings.append(ReviewFinding("warning", f"No {product} integration detected"))
    repeated = repeated_paragraphs(body)
    for paragraph, count in repeated[:3]:
        findings.append(
            ReviewFinding(
                "warning" if count < 5 else "error",
                f"Repeated paragraph detected {count} times",
                excerpt=paragraph[:220],
            )
        )
    for pattern, message in RISK_PATTERNS:
        match = re.search(pattern, body, flags=re.I | re.S)
        if match:
            findings.append(ReviewFinding("error", message, excerpt=body[max(0, match.start() - 80) : match.end() + 80]))
    # Editorial comments (image briefs and internal-link notes) are intentionally
    # stripped by the public exporters, so they are not publishable placeholders.
    placeholder_body = re.sub(r"<!--.*?-->", "", body, flags=re.S)
    for pattern in PLACEHOLDER_PATTERNS:
        match = re.search(pattern, placeholder_body, flags=re.I)
        if match:
            findings.append(ReviewFinding("error", "Placeholder text detected", excerpt=match.group(0)))
    evidence_sources = 0
    if evidence_path and evidence_path.exists():
        evidence = json.loads(read_text(evidence_path))
        evidence_sources = len(evidence.get("evidence", []))
        if evidence_sources < 3:
            findings.append(ReviewFinding("warning", f"Evidence pack is thin: {evidence_sources} sources"))
    else:
        findings.append(ReviewFinding("warning", "No evidence pack found for this article"))
    status = "pass"
    if any(item.severity == "error" for item in findings):
        status = "fail"
    elif any(item.severity == "warning" for item in findings):
        status = "needs_review"
    return {
        "article": str(article_path),
        "status": status,
        "word_count": wc,
        "h2_count": h2_count,
        "evidence_sources": evidence_sources,
        "findings": [item.__dict__ for item in findings],
    }


def repeated_paragraphs(text: str) -> list[tuple[str, int]]:
    paragraphs = [
        re.sub(r"\s+", " ", item).strip()
        for item in re.split(r"\n\s*\n", text)
        if len(re.sub(r"\s+", " ", item).strip()) > 80
    ]
    counts: dict[str, int] = {}
    for paragraph in paragraphs:
        counts[paragraph] = counts.get(paragraph, 0) + 1
    return sorted(((p, c) for p, c in counts.items() if c >= 3), key=lambda item: item[1], reverse=True)


def review_manifest(manifest_path: Path, output_path: Path | None = None) -> dict:
    manifest = json.loads(read_text(manifest_path))
    results = []
    for item in manifest.get("items", []):
        if item.get("status") != "article":
            results.append(
                {
                    "article": item.get("output"),
                    "status": "not_generated",
                    "findings": [{"severity": "info", "message": "Only a brief/prompt was generated"}],
                }
            )
            continue
        results.append(review_article(Path(item["output"]), Path(item["evidence"]) if item.get("evidence") else None))
    generated_sequence: list[tuple[dict, dict[str, str | int | None]]] = []
    for item, result in zip(manifest.get("items", []), results):
        article_path = Path(item.get("output", ""))
        if item.get("status") == "article" and article_path.exists():
            for slot in generated_image_slots(read_text(article_path)):
                generated_sequence.append((result, slot))
    sequence_start = int(manifest.get("visual_sequence_start", 1))
    for expected_index, (result, slot) in enumerate(generated_sequence, start=sequence_start):
        if slot["sequence_index"] == expected_index:
            continue
        result.setdefault("findings", []).append(
            {
                "severity": "error",
                "message": (
                    f"Generated visual sequence must be global and contiguous: "
                    f"IMAGE_SLOT_{int(slot['slot_id']):02d} has index {slot['sequence_index']}, expected {expected_index}"
                ),
                "excerpt": None,
            }
        )
        result["status"] = "fail"
    summary = {
        "manifest": str(manifest_path),
        "total": len(results),
        "pass": sum(1 for item in results if item.get("status") == "pass"),
        "needs_review": sum(1 for item in results if item.get("status") == "needs_review"),
        "fail": sum(1 for item in results if item.get("status") == "fail"),
        "not_generated": sum(1 for item in results if item.get("status") == "not_generated"),
        "results": results,
    }
    if output_path:
        write_text(output_path, json.dumps(summary, ensure_ascii=False, indent=2) + "\n")
    return summary
