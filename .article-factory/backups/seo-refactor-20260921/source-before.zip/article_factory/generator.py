from __future__ import annotations

import json
import re
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from .db import KnowledgeDb
from .io_utils import clamp_words, slugify, write_text
from .llm import LlmResult, call_llm
from .products import product_for_game


RESTRICTED_EVIDENCE_PATTERNS = [
    r"\bhwid\b",
    r"spoofer|спуфер",
    r"anti-?cheat|античит|\bvac\b|faceit",
    r"bypass|evade|обход|обойти",
    r"inject|инжект|driver|kernel|драйвер",
    r"100%\s+(?:undetected|safe|guarantee|безопасн|гарант)",
    r"undetected|не\s*детект",
    r"cheats?\s+are\s+the\s+fastest",
    r"solve\s+this\s+in\s+one\s+click",
    r"developer\s+1|dota_game_account_debug",
    r"all-hero\s+scripts|hero\s+scripts|auto-?combo",
]

SYSTEM_EVIDENCE_SOURCES = {
    "README.md",
    "AGENTS.md",
    "SEO_ARTICLE_RULES.md",
    "CURRENT_CODEX_TASK.md",
    "SYSTEM_ARCHITECTURE.md",
    "PRODUCT_REQUIREMENTS.md",
    "AI_MEMORY_INTEGRATION.md",
    "knowledge/schema.md",
}


@dataclass
class ArticleSpec:
    raw: str
    count: int = 10
    language: str = "en"
    game: str = "all"
    style: str = "Medium-style, direct, practical, conversational, lightly slangy, gamer-aware, expert voice, no filler"
    volume: str | None = None
    ad_mode: str = "native"


def parse_spec(text: str, *, count: int | None = None, game: str | None = None, language: str | None = None) -> ArticleSpec:
    spec = ArticleSpec(raw=text)
    count_match = re.search(r"(\d{1,2})\s*(?:seo\s*)?(?:стат|article)", text, flags=re.I)
    if count_match:
        spec.count = int(count_match.group(1))
    if count is not None:
        spec.count = count
    if game:
        spec.game = game
    elif re.search(r"\bcs2\b|кс\s*2|counter", text, flags=re.I):
        spec.game = "cs2"
    elif re.search(r"\bdota\b|дота", text, flags=re.I):
        spec.game = "dota2"
    if language:
        spec.language = language
    elif re.search(r"\b(en|english|англ)", text, flags=re.I):
        spec.language = "en"
    elif re.search(r"\b(ru|рус|русск)", text, flags=re.I):
        spec.language = "ru"
    volume_match = re.search(r"(\d[\d\s]{2,})\s*(слов|words|знаков|символ)", text, flags=re.I)
    if volume_match:
        spec.volume = f"{volume_match.group(1).strip()} {volume_match.group(2)}"
    style_match = re.search(r"в стиле[:\s]+(.+?)(?:,|\.|$)", text, flags=re.I)
    if style_match:
        spec.style = style_match.group(1).strip()
    return spec


def make_fts_query(text: str) -> str:
    terms = re.findall(r"[\wа-яёА-ЯЁ]{3,}", text)
    seen: list[str] = []
    for term in terms:
        low = term.lower()
        if low not in seen:
            seen.append(low)
    return " OR ".join(seen[:8])


SPEC_STOPWORDS = {
    "generate",
    "write",
    "article",
    "articles",
    "about",
    "with",
    "integrate",
    "integration",
    "native",
    "seo",
    "words",
    "style",
    "game",
    "deadlock",
    "dota",
    "cs2",
    "cluster",
    "center",
    "melonity",
}


def spec_terms(text: str) -> list[str]:
    terms: list[str] = []
    for term in re.findall(r"[a-zA-Z0-9а-яА-ЯёЁ]{3,}", text.lower()):
        if term in SPEC_STOPWORDS or term in terms:
            continue
        terms.append(term)
    return terms[:12]


def rank_topics_for_spec(topics: list[dict], spec: ArticleSpec) -> list[dict]:
    terms = spec_terms(spec.raw)
    if not terms:
        return topics
    ranked: list[tuple[float, dict]] = []
    for topic in topics:
        evidence = " ".join(json.loads(topic.get("evidence_json") or "[]"))
        haystack = " ".join(
            str(topic.get(field) or "")
            for field in ("title", "cluster", "main_query", "ad_integration")
        )
        haystack = f"{haystack} {evidence}".lower()
        matches = sum(1 for term in terms if term in haystack)
        exact_bonus = 0
        for term in terms:
            if term and term in str(topic.get("main_query") or "").lower():
                exact_bonus += 4
            elif term and term in str(topic.get("title") or "").lower():
                exact_bonus += 3
        ranked.append((float(topic.get("score") or 0) + matches * 12 + exact_bonus, topic))
    return [topic for _, topic in sorted(ranked, key=lambda item: item[0], reverse=True)]


def build_evidence_pack(db: KnowledgeDb, topic: dict, language: str, limit: int = 10) -> list[dict]:
    product = product_for_game(topic.get("game"))
    queries = [
        topic.get("title") or "",
        topic.get("main_query") or "",
        topic.get("cluster") or "",
        f"Tone of Voice SEO article content pattern {product}",
        f"product features {product} TOV SEO article",
        "product map cluster.center Melonity",
    ]
    rows = []
    seen = set()
    for query in queries:
        fts_query = make_fts_query(query)
        for row in db.search_chunks(fts_query or query, limit=limit):
            if row["source_path"] in SYSTEM_EVIDENCE_SOURCES:
                continue
            if is_irrelevant_product_evidence(topic, row):
                continue
            key = (row["source_path"], row["heading"])
            if key in seen:
                continue
            body = row["body"]
            if topic.get("risk_level") == "normal" and is_restricted_evidence(row["heading"], body):
                continue
            seen.add(key)
            rows.append(
                {
                    "source": row["source_path"],
                    "heading": row["heading"],
                    "excerpt": clamp_words(body, 180),
                }
            )
            if len(rows) >= limit:
                return rows
    return rows


def is_irrelevant_product_evidence(topic: dict, row: dict) -> bool:
    game = (topic.get("game") or "").lower()
    if game not in {"deadlock", "cs2"}:
        return False
    text = f"{row['source_path']}\n{row['heading']}\n{row['body']}".lower()
    allowed_markers = ["cluster.center", "cluster center", "product-map", "deadlock-cs2-cluster-center"]
    if game == "deadlock":
        allowed_markers.extend(["deadlock", "deadlock-cluster-center"])
    if game == "cs2":
        allowed_markers.extend(["cs2", "counter-strike", "counter strike", "semantic_core_cs2"])
    if any(marker in text for marker in allowed_markers):
        return False
    wrong_markers = ["melonity", "dota 2", "dota2", "melonity-knowledge-base", "melonity-seo-cluster-map"]
    return any(marker in text for marker in wrong_markers)


def is_restricted_evidence(heading: str, body: str) -> bool:
    text = f"{heading}\n{body}"
    return any(re.search(pattern, text, flags=re.I | re.S) for pattern in RESTRICTED_EVIDENCE_PATTERNS)


def build_prompt(spec: ArticleSpec, topic: dict, evidence: list[dict]) -> str:
    outline = json.loads(topic.get("outline_json") or "[]")
    topic_evidence = json.loads(topic.get("evidence_json") or "[]")
    lang_name = "Russian" if spec.language == "ru" else "English"
    volume = spec.volume or topic.get("volume_words") or ("8,000-12,000 знаков" if spec.language == "ru" else "1,500-2,200 words")
    product = product_for_game(topic.get("game") or spec.game)
    source_notes = "\n\n".join(
        f"### Source: {item['source']} / {item['heading']}\n{item['excerpt']}" for item in evidence
    )
    outline_text = "\n".join(f"- {item}" for item in outline) if outline else "- Build the best SEO structure for the topic."
    topic_evidence_text = "\n".join(f"- {item}" for item in topic_evidence)
    return f"""You are an expert SEO editor and game-content researcher.

Write a useful, non-generic SEO article in {lang_name}.

USER SPEC:
{spec.raw}

ARTICLE TARGET:
- Title: {topic.get('title')}
- Game: {topic.get('game')}
- Main query: {topic.get('main_query')}
- Cluster: {topic.get('cluster')}
- Risk level: {topic.get('risk_level', 'normal')}
- Target volume: {volume}
- Style: {spec.style}
- Advertising mode: {spec.ad_mode}
- Product to integrate: {product}

SEO / TOPIC EVIDENCE:
{topic_evidence_text}

SUGGESTED OUTLINE:
{outline_text}

BACKGROUND NOTES FOR THE WRITER (do not name these in the article):
{source_notes}

STRICT RULES:
- Use the background notes and verified facts internally; do not mention "local sources", "local evidence", "evidence pack", or "knowledge base" in the final article body.
- Write public-facing claims from an expert editorial perspective: "from our experience", "in practice", "what players usually run into", or similar natural wording.
- Use only supported facts or mark uncertainty explicitly.
- Do not invent current patch, price, ban-wave, anti-cheat, or product-status facts.
- Do not provide operational instructions for bypassing anti-cheat, evading detection, exploiting vulnerabilities, or implementing cheats.
- If risk level is `restricted`, write only a high-level educational/risk-aware article and refuse operational steps.
- You may mention {product} as a product/brand in a native ad block, but do not make unsupported safety guarantees.
- Respect product mapping: Dota 2 uses Melonity; Deadlock and CS2 use cluster.center.
- Make the article genuinely useful: explain context, user intent, mistakes, practical checklists, FAQ, and internal-link ideas.
- Match the imported Medium source style: direct, practical, conversational, lightly slangy, gamer-aware, and free from water, corporate wording, bureaucratic phrasing, or academic over-explaining.
- Keep the target volume useful but tight: cover the intent completely, without padding.
- Do not use markdown tables. Use bullet lists, numbered lists, and comparison lists instead.
- Return Markdown with front matter: title, description, game, language, primary_keyword, secondary_keywords.
"""


def estimate_target_words(spec: ArticleSpec, topic: dict) -> int:
    text = spec.volume or topic.get("volume_words") or ""
    nums = [int(match) for match in re.findall(r"\d{3,5}", text.replace(",", ""))]
    if nums:
        return max(nums)
    return 1600 if spec.language == "en" else 1200


def keyword_list(topic: dict) -> list[str]:
    values: list[str] = []
    for field in ("main_query", "cluster", "title"):
        value = topic.get(field)
        if value and value not in values:
            values.append(str(value))
    try:
        evidence = json.loads(topic.get("evidence_json") or "[]")
        for item in evidence:
            if isinstance(item, str) and len(item) <= 90 and item not in values:
                values.append(item)
    except json.JSONDecodeError:
        pass
    return values[:12]


def generate_template_article(spec: ArticleSpec, topic: dict, evidence: list[dict]) -> str:
    """Deterministic no-API fallback that turns evidence into a publishable draft skeleton."""
    language = spec.language
    title = topic.get("title") or "SEO Article"
    primary = topic.get("main_query") or title
    product = product_for_game(topic.get("game") or spec.game)
    description = (
        f"A practical, evidence-based guide to {primary} with clear context, common mistakes, FAQs, and a native {product} mention."
        if language == "en"
        else f"Практический разбор темы «{primary}»: контекст, ошибки, FAQ и нативное упоминание {product}."
    )
    keys = keyword_list(topic)
    evidence_items = evidence[:8]
    facts = []
    for item in evidence_items:
        facts.append(
            {
                "heading": item["heading"],
                "source": item["source"],
                "excerpt": item["excerpt"].replace("\n", " ").strip(),
            }
        )
    target = estimate_target_words(spec, topic)
    if language == "ru":
        return template_article_ru(spec, topic, title, description, primary, keys, facts, target, product)
    return template_article_en(spec, topic, title, description, primary, keys, facts, target, product)


def source_bullets(facts: list[dict], max_items: int = 6) -> str:
    lines = []
    for fact in facts[:max_items]:
        excerpt = clamp_words(fact["excerpt"], 45)
        lines.append(f"- `{fact['source']}` / {fact['heading']}: {excerpt}")
    return "\n".join(lines)


def template_article_en(
    spec: ArticleSpec,
    topic: dict,
    title: str,
    description: str,
    primary: str,
    keys: list[str],
    facts: list[dict],
    target: int,
    product: str,
) -> str:
    risk = topic.get("risk_level", "normal")
    outline = json.loads(topic.get("outline_json") or "[]")
    if not outline:
        outline = [
            f"What {primary} means",
            "Why players search for it",
            "Practical checklist",
            f"Where {product} fits",
            "FAQ",
        ]
    source_notes = source_bullets(facts)
    sections = []
    section_angles = [
        "Start with the reader's intent: what problem they are trying to solve and what they probably misunderstand.",
        "Separate stable game concepts from fast-changing claims that would need a fresh source.",
        "Turn the idea into a practical checklist rather than a promise of instant results.",
        "Use grounded examples, but keep uncertain details cautious.",
        "Connect the topic to adjacent internal links from the same semantic cluster.",
        "Explain the product angle only after the educational answer is useful by itself.",
        "Close the loop with realistic expectations and a reason to keep reading.",
    ]
    section_takeaways = [
        "The reader should leave this section with one concrete next step, not just a definition.",
        "If the article cannot verify a claim from the writer notes, it should frame that claim as uncertain.",
        "For SEO, this section should answer a sub-question that could stand as its own long-tail query.",
        "The strongest examples are the ones tied to real player behavior: tilt, reports, settings, consistency, or match pressure.",
        "This is also a good place to add an internal link to a related guide from the same cluster.",
        "A product mention belongs here only when it clarifies a choice the reader already understands.",
        "The final paragraph should reduce hype and help the reader make a calmer decision.",
    ]
    for index, item in enumerate(outline[:7]):
        fact = facts[index % len(facts)] if facts else {"source": "project memory", "excerpt": "", "heading": ""}
        angle = section_angles[index % len(section_angles)]
        takeaway = section_takeaways[index % len(section_takeaways)]
        sections.append(
            f"""## {item}

{angle} In practice, the useful angle here is: {clamp_words(fact['excerpt'], 38)}

{takeaway} Keep the paragraph grounded in the user's real match experience and avoid turning the section into filler. If stronger notes are added later, this is exactly the kind of block that should be regenerated with more specific examples.
"""
        )
    body = f"""---
title: "{title}"
description: "{description}"
game: {topic.get('game')}
language: en
primary_keyword: "{primary}"
secondary_keywords: {json.dumps(keys[1:8], ensure_ascii=False)}
generated_by: template_fallback
risk_level: {risk}
---

# {title}

If you searched for **{primary}**, you probably do not need another shallow list of generic tips. You need a clear explanation of what is actually happening, what players usually misunderstand, and how to turn that knowledge into better decisions in real matches.

This guide is written from a practical expert angle: what players usually misunderstand, what matters in real matches, and where claims need to stay cautious instead of turning into hype.

## Quick Answer

{primary} is a high-intent topic because it sits between game knowledge, player frustration, and practical improvement. The best article angle is not to promise a miracle. The best angle is to explain the mechanics, show the common mistakes, and give the reader a stable checklist they can apply before the next match.

For {product}, the native integration should stay grounded: present it as a tool that can support cleaner execution, awareness, and consistency when the current product facts support that framing. Do not claim that it directly fixes account state, removes penalties, guarantees safety, or changes matchmaking outcomes.

{''.join(sections)}

## Practical Checklist

- Define the exact problem before looking for a tool or shortcut.
- Compare the search query with the real match situation: behavior, mechanics, settings, account context, or decision-making.
- Use the article's primary keyword naturally in the title, introduction, one H2, and FAQ.
- Add related long-tail keywords only where they answer a real reader question.
- Keep product mentions native: one short contextual paragraph is usually stronger than repeated hard selling.
- Avoid unsupported claims about current patch state, anti-cheat status, ban waves, or guaranteed outcomes.

## Where {product} Fits

{product} can be introduced as a premium gaming-assistance product in a short, native block after the educational part of the article has already delivered value. The safest framing is performance and consistency: fewer mechanical mistakes, clearer awareness, and a more controlled experience where the feature set actually supports that claim.

The article should not say that {product} automatically solves the reader's problem. It should say that if the reader already understands the underlying issue and wants an additional tool, {product} is one option to evaluate through the official site, trial terms, current feature list, and up-to-date product information.

## SEO Structure Notes

The title should lead with the real user query. The meta description should promise clarity, not hype. The introduction should answer the search intent quickly, then the body can expand into examples, mistakes, and a checklist. Internal links should point to adjacent topics from the same cluster, especially guides about behavior, account state, settings, reports, or game-specific mechanics.

## FAQ

### Is this topic only commercial?

No. The best page should be useful even before the reader reaches the product mention. Commercial intent can exist, but the article should first explain the game context and the problem behind the query.

### Should the article include {product} in every section?

No. One native section plus one soft CTA is usually enough. Repeating the product name too often makes the page feel less trustworthy.

### Can the article mention current patches or ban waves?

Only if fresh verified information is added to the project notes. Otherwise, use evergreen wording and mark uncertainty clearly.

### What makes this article better than a generic AI draft?

It starts from clustered search intent, uses verified facts, avoids unsupported promises, and keeps the ad integration tied to the reader's actual problem.

## Editorial CTA

If you want a more stable way to approach this topic, start with the checklist above, then compare it with the current {product} feature set and trial terms on the official product side. The strongest decision is the one based on real match needs, not on hype.
"""
    if len(body.split()) < min(target, 1200):
        body += """

## Additional Editorial Expansion

A strong SEO article in this niche should feel like it was written by someone who understands why players search for the topic after a frustrating session. The reader may be angry, curious, skeptical, or comparing tools. Good content should meet that state directly: explain the issue, separate myths from what the sources can support, and give practical next steps without pretending that one product line can replace judgment.

That is also why the internal writer notes matter. They keep the draft from drifting into generic filler. If a future source adds more detail, the same article can be regenerated with stronger examples, updated FAQs, and better internal links while preserving the original editorial rules.
"""
    return body.strip() + "\n"


def template_article_ru(
    spec: ArticleSpec,
    topic: dict,
    title: str,
    description: str,
    primary: str,
    keys: list[str],
    facts: list[dict],
    target: int,
    product: str,
) -> str:
    risk = topic.get("risk_level", "normal")
    source_notes = source_bullets(facts)
    body = f"""---
title: "{title}"
description: "{description}"
game: {topic.get('game')}
language: ru
primary_keyword: "{primary}"
secondary_keywords: {json.dumps(keys[1:8], ensure_ascii=False)}
generated_by: template_fallback
risk_level: {risk}
---

# {title}

Если пользователь ищет **{primary}**, ему нужен не сухой набор общих советов, а понятный разбор: что происходит, почему это важно в игре, какие ошибки встречаются чаще всего и как принять нормальное решение без мифов и пустых обещаний.

Этот материал пишется с экспертной позиции: что игроки обычно путают, что реально важно в матче и где лучше говорить осторожно, а не разгонять хайп без подтверждения.

## Короткий ответ

Тема `{primary}` важна потому, что она соединяет игровой интент, боль игрока и практический запрос. Хорошая SEO-статья должна быстро объяснить суть, показать типичные ошибки и дать читателю применимый план действий.

## Что важно понять

Главная ошибка в таких темах — писать статью как рекламную страницу. Это снижает доверие и делает текст похожим на шаблон. Сначала нужно закрыть образовательную часть: объяснить контекст, разобрать термины, показать, где игроки обычно ошибаются, и только потом аккуратно встроить продукт.

## Практический чеклист

- Сформулировать конкретную проблему пользователя.
- Проверить, какие факты подтверждены внутренними заметками и актуальными данными.
- Не обещать гарантированные результаты.
- Использовать главный ключ в H1, intro, одном H2 и FAQ.
- Добавить нативный блок {product} только там, где он логически связан с темой.
- Не писать инструкции по обходу античита, эксплуатации уязвимостей или реализации чит-функций.

## Где уместен {product}

{product} лучше встроить после полезного объяснения темы. Безопасный фрейм — стабильность, внимательность, меньше механических ошибок и более контролируемый игровой опыт, если это подтверждается текущей базой знаний. Не нужно обещать, что продукт автоматически решает проблему пользователя.

## SEO-структура

Статья должна начинаться с прямого ответа на интент. Далее идут объяснение, ошибки, чеклист, нативная интеграция, FAQ и мягкий CTA. Внутренние ссылки стоит вести на соседние материалы из того же кластера.

## FAQ

### Можно ли делать статью полностью рекламной?

Нет. Лучше сначала дать пользу, иначе текст будет слабым и для читателя, и для поиска.

### Нужно ли упоминать {product} в каждом блоке?

Нет. Достаточно одного нативного блока и мягкого CTA.

### Можно ли писать про свежий патч или бан-волны?

Только если свежая информация добавлена в проект и подтверждена перед публикацией.

## Вывод

Сильная статья по этой теме должна быть полезной сама по себе. Реклама работает лучше, когда она встроена в понятный контекст и не пытается заменить факты громкими обещаниями.
"""
    if len(body.split()) < min(target, 1000):
        body += """

## Редакторское расширение

Для автономной генерации особенно важно, чтобы система не подменяла факты уверенностью модели. Если в базе знаний мало данных, текст должен честно оставаться осторожным: лучше добавить ссылку, PDF или markdown-заметку и переиндексировать проект, чем получать красивый, но недостоверный материал.

Такой подход позволяет постепенно наращивать качество. Каждая новая публикация, ссылка и продуктовая заметка становятся частью общей памяти, а следующие статьи получают более точные темы, более сильные аргументы и меньше повторов.
"""
    return body.strip() + "\n"


def fallback_brief(spec: ArticleSpec, topic: dict, evidence: list[dict], prompt_path: str) -> str:
    product = product_for_game(topic.get("game") or spec.game)
    outline = json.loads(topic.get("outline_json") or "[]")
    topic_evidence = json.loads(topic.get("evidence_json") or "[]")
    lines = [
        "---",
        f"title: {json.dumps(topic.get('title'), ensure_ascii=False)}",
        f"game: {topic.get('game')}",
        f"language: {spec.language}",
        "status: needs_llm",
        f"prompt: {prompt_path}",
        "---",
        "",
        f"# {topic.get('title')}",
        "",
        "This file is an article brief. Codex should write the final article manually from this prompt and evidence; do not require an external LLM API.",
        "",
        "## Target",
        f"- Main query: {topic.get('main_query')}",
        f"- Cluster: {topic.get('cluster')}",
        f"- Volume: {spec.volume or topic.get('volume_words') or 'auto'}",
        f"- Style: {spec.style}",
        "- Formatting: no markdown tables; use lists only.",
        "",
        "## Evidence",
    ]
    lines.extend(f"- {item}" for item in topic_evidence[:20])
    lines.append("")
    lines.append("## Suggested Structure")
    if outline:
        lines.extend(f"- {item}" for item in outline)
    else:
        lines.extend(
            [
                "- Search intent and quick answer",
                "- Main explanation",
                "- Practical examples",
                f"- {product} native integration",
                "- FAQ",
            ]
        )
    lines.append("")
    lines.append("## Source Pack")
    for item in evidence:
        lines.append(f"### {item['heading']}")
        lines.append(f"Source: `{item['source']}`")
        lines.append("")
        lines.append(item["excerpt"])
        lines.append("")
    return "\n".join(lines).strip() + "\n"


def generate_articles(
    db_path: Path,
    output_root: Path,
    spec_text: str,
    *,
    count: int | None = None,
    game: str | None = None,
    language: str | None = None,
    llm_provider: str = "none",
    model: str | None = None,
    mark_used: bool = False,
    include_restricted: bool = False,
) -> dict:
    db = KnowledgeDb(db_path)
    db.init()
    spec = parse_spec(spec_text, count=count, game=game, language=language)
    candidate_count = max(spec.count * 8, 50)
    topics = [dict(row) for row in db.list_topics(spec.game, spec.language, candidate_count, include_restricted=include_restricted)]
    if len(topics) < spec.count and spec.language != "all":
        topics.extend(
            dict(row)
            for row in db.list_topics(spec.game, "all", candidate_count - len(topics), include_restricted=include_restricted)
        )
    topics = rank_topics_for_spec(topics, spec)
    run_stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    article_dir = output_root / "articles" / run_stamp
    prompt_dir = output_root / "prompts" / run_stamp
    brief_dir = output_root / "briefs" / run_stamp
    evidence_dir = output_root / "evidence" / run_stamp
    manifest = {
        "created_at": run_stamp,
        "spec": spec.__dict__,
        "llm_provider": llm_provider,
        "model": model,
        "items": [],
    }
    used_ids: list[int] = []
    for idx, topic in enumerate(topics[: spec.count], start=1):
        evidence = build_evidence_pack(db, topic, spec.language)
        prompt = build_prompt(spec, topic, evidence)
        slug = f"{idx:02d}-{slugify(topic['title'])}"
        prompt_path = prompt_dir / f"{slug}.md"
        evidence_path = evidence_dir / f"{slug}.json"
        write_text(prompt_path, prompt)
        write_text(
            evidence_path,
            json.dumps(
                {
                    "topic": topic,
                    "evidence": evidence,
                    "strict_rules": [
                        "Use only supported facts or mark uncertainty explicitly.",
                        "Do not mention local sources, local evidence, evidence packs, or the knowledge base in the final article body; write from an expert editorial voice.",
                        "Do not invent current patch, price, ban-wave, anti-cheat, or product-status facts.",
                        "Do not provide operational anti-cheat evasion, exploit, or cheat-implementation instructions.",
                        "Do not use markdown tables; use lists instead.",
                        "Match the imported Medium style: direct, practical, conversational, lightly slangy, and no filler.",
                    ],
                },
                ensure_ascii=False,
                indent=2,
            )
            + "\n",
        )
        if llm_provider == "template":
            result = LlmResult(
                text=generate_template_article(spec, topic, evidence),
                provider="template",
                model="deterministic-template",
            )
        else:
            result = call_llm(llm_provider, prompt, model)
        if result.text.strip():
            article_path = article_dir / f"{slug}.md"
            write_text(article_path, result.text.strip() + "\n")
            status = "article"
            output_path = article_path
        else:
            brief_path = brief_dir / f"{slug}.md"
            brief = fallback_brief(spec, topic, evidence, str(prompt_path))
            write_text(brief_path, brief)
            status = "brief"
            output_path = brief_path
        manifest["items"].append(
            {
                "topic_id": topic["id"],
                "title": topic["title"],
                "game": topic["game"],
                "language": topic["language"],
                "status": status,
                "output": str(output_path),
                "prompt": str(prompt_path),
                "evidence": str(evidence_path),
                "llm_error": result.error,
            }
        )
        used_ids.append(int(topic["id"]))
    manifest_path = output_root / "runs" / f"{run_stamp}.json"
    write_text(manifest_path, json.dumps(manifest, ensure_ascii=False, indent=2))
    db.record_run(spec_text, {"count": count, "game": game, "language": language, "llm": llm_provider, "model": model}, str(manifest_path))
    if mark_used:
        db.mark_topics_used(used_ids)
    db.close()
    return manifest
