---
description: "Гайды по Dota 2 и архив русскоязычных материалов на Medium."
---

# Гайды по Dota 2

Актуальную страницу продукта смотрите по ссылке [читы для Dota 2 от Melonity](https://melonity.gg/). Заголовки материалов ниже сохранены для навигации и сами по себе не означают гарантию безопасности или совместимости.

## Оригинальный гайд

* [Телепорт в Dota 2: как одно перемещение меняет три линии](teleport-v-dota-2-kak-menyaetsya-karta.md)

## Статьи на Medium

* [Топ читов для Dota 2](https://medium.com/@mrkhertz/%D1%82%D0%BE%D0%BF-%D1%87%D0%B8%D1%82%D0%BE%D0%B2-%D0%B4%D0%BB%D1%8F-dota-2-%D0%BB%D1%83%D1%87%D1%88%D0%B8%D0%B9-%D1%87%D0%B8%D1%82-7317890f8f18)
* [Maphack для Dota 2: обзор](https://medium.com/@mrkhertz/maphack-%D0%B4%D0%BB%D1%8F-dota-2-%D0%B2%D1%81%D1%91-%D1%87%D1%82%D0%BE-%D0%BD%D1%83%D0%B6%D0%BD%D0%BE-%D0%B7%D0%BD%D0%B0%D1%82%D1%8C-%D0%B8-%D0%BA%D0%B0%D0%BA-%D0%B5%D0%B3%D0%BE-%D1%81%D0%BA%D0%B0%D1%87%D0%B0%D1%82%D1%8C-e4e962740539)
