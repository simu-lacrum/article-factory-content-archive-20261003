---
description: "Гайды по экономике линии, душам и принятию решений в Deadlock."
---

# Гайды по Deadlock

* [Души в Deadlock: как проигрывают линию между добиванием и подтверждением](dushi-v-deadlock-dobivanie-podtverzhdenie-liniya.md)
