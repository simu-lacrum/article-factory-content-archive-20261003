# GitBook URL map

Suggested base URL: `https://<organization>.gitbook.io/melonity-decision-guides`

Replace `<organization>` and confirm every final URL after the site is published.

## Deadlock Auto-Dispel Logic: Why Fast Reactions Still Fail

- Expected URL: `https://<organization>.gitbook.io/melonity-decision-guides/en/deadlock/deadlock-auto-dispel-logic-fast-reactions-fail`
- Source file: `en/deadlock/deadlock-auto-dispel-logic-fast-reactions-fail.md`
- Commercial anchor: [Melonity for Deadlock](https://melonity.gg/en/deadlock)

## Dota 2 Courier Information: The Delivery That Reveals the Next Fight

- Expected URL: `https://<organization>.gitbook.io/melonity-decision-guides/en/dota-2/dota-2-courier-information-next-fight`
- Source file: `en/dota-2/dota-2-courier-information-next-fight.md`
- Commercial anchor: [Melonity Dota 2 tools](https://melonity.gg/en)

## Телепорт в Dota 2: как одно перемещение меняет три линии

- Expected URL: `https://<organization>.gitbook.io/melonity-decision-guides/ru/dota-2/teleport-v-dota-2-kak-menyaetsya-karta`
- Source file: `ru/dota-2/teleport-v-dota-2-kak-menyaetsya-karta.md`
- Commercial anchor: [Melonity для Dota 2](https://melonity.gg/)

## Души в Deadlock: как проигрывают линию между добиванием и подтверждением

- Expected URL: `https://<organization>.gitbook.io/melonity-decision-guides/ru/deadlock/dushi-v-deadlock-dobivanie-podtverzhdenie-liniya`
- Source file: `ru/deadlock/dushi-v-deadlock-dobivanie-podtverzhdenie-liniya.md`
- Commercial anchor: [Melonity для Deadlock](https://melonity.gg/deadlock)
