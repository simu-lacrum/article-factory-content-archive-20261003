---
description: "Deadlock guides focused on defensive decisions and clear feature evaluation."
---

# Deadlock Guides

* [Deadlock Auto-Dispel Logic: Why Fast Reactions Still Fail](deadlock-auto-dispel-logic-fast-reactions-fail.md)
