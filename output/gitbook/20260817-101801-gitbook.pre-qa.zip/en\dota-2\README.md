---
description: "Dota 2 guides about courier information, timing and map decisions."
---

# Dota 2 Guides

* [Dota 2 Courier Information: The Delivery That Reveals the Next Fight](dota-2-courier-information-next-fight.md)
