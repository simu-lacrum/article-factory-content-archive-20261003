---
description: "Русскоязычные материалы о принятии решений в Dota 2 и Deadlock."
---

# Гайды на русском

* [Гайды по Dota 2](dota-2/README.md)
* [Гайды по Deadlock](deadlock/README.md)
