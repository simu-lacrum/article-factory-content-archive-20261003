---
description: "English decision guides for Deadlock and Dota 2."
---

# English Guides

* [Deadlock guides](deadlock/README.md)
* [Dota 2 guides](dota-2/README.md)
